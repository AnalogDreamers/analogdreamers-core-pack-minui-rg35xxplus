No BIOS required or handled by core.
