Analog Dreamers – Core Collection v1.1 — Definitive Edition
(RG35XX Plus / RGCubeXX MinUI Build)

🌈 Übersicht
Willkommen zur Analog Dreamers Core Collection v1.1 — einer vollständig getesteten, sofort spielbereiten Retro-Erfahrung für RG35XX Plus und RGCubeXX.
Jedes System wurde für maximale Kompatibilität und Benutzerfreundlichkeit konfiguriert – basierend auf dem „Robust Edition“-Standard dieses Builds.

🎮 Enthaltene Robuste Systeme
# | System | Core | BIOS-Ordner | Hinweise
1 | Atari 2600 | stella2014_libretro.so | — | Schnell, kein BIOS erforderlich
2 | Atari 5200 | atari800_libretro.so | /Bios/AT5200/ | Benötigt 5200.rom
3 | Atari Lynx | handy_libretro.so | /Bios/ATLYNX/ | Benötigt lynxboot.img
4 | Atari 7800 | prosystem_libretro.so | /Bios/AT7800/ | 7800 BIOS (U).rom oder (E).rom
5 | Sega CD | genesis_plus_gx_libretro.so | /Bios/SEGACD/ | Regionsabhängige BIOS-Dateien erforderlich
6 | PC Engine / TurboGrafx-16 | beetle_pce_fast_libretro.so | /Bios/PCECD/ | syscard1.pce, syscard2.pce, syscard3.pce
7 | Neo Geo | fbalpha2012_neogeo_libretro.so | /Bios/NEOGEO/ | Benötigt neogeo.zip
8 | C64 | vice_x64_libretro.so | /Bios/C64/ | Original C64 BIOS-Set
9 | Amiga | puae_libretro.so | /Bios/AMIGA/ | kick13.rom, kick20.rom, kick31.rom
10 | Amiga CD | puae_libretro.so | /Bios/AMIGACD/ | CD32 BIOS erforderlich
11 | Atari ST | hatari_libretro.so | /Bios/ATARIST/ | Benötigt tos.img
12 | CPS / CPS2 / CPS3 | fbalpha2012_cps_libretro.so | — | Kein BIOS erforderlich
13 | SG-1000 | genesis_plus_gx_libretro.so | /Bios/SG1000/ | Optionales BIOS
14 | Sega 32X | picodrive_libretro.so | /Bios/SEGA32X/ | Regionsabhängige BIOS-Dateien erforderlich
15 | Naomi / Atomiswave | flycast_libretro.so | /Bios/NAOMI/ | Korrektes ROM-Set erforderlich
16 | Game & Watch | gw_libretro.so | — | Minimales System, kein BIOS

⚙️ Installationsanleitung
1️⃣ Kopiere alle Ordner aus dieser ZIP-Datei in das Hauptverzeichnis deiner SD-Karte.
2️⃣ Lege die BIOS-Dateien in die entsprechenden Ordner (Dateinamen müssen exakt übereinstimmen).
3️⃣ ROMs gehören in die jeweiligen /Roms/[SystemName]/ Ordner.
4️⃣ Starte dein Gerät und wähle die .pak-Datei des gewünschten Systems.
5️⃣ Sofort spielbereit — keine Einrichtung erforderlich!

🖥️ Anzeigeeinstellungen
Alle Systeme sind vorkonfiguriert mit:
- Seitenverhältnis: Vom Core vorgegeben
- Integer Scale: AUS
- Stretch: VOLLBILD (nur bei kompatiblen Cores)
Diese Einstellungen kannst du später in RetroArch nach Wunsch ändern.

💾 Beispielhafte Ordnerstruktur
/mnt/sdcard/
├── Bios/
│   ├── AT5200/5200.rom
│   ├── ATLYNX/lynxboot.img
│   ├── PCECD/syscard3.pce
│   └── ...
├── Roms/
│   ├── Atari 2600/
│   ├── Sega CD/
│   ├── Amiga CD/
│   └── ...
└── Emus/
    ├── rg35xxplus/
    │   ├── A2600.pak/
    │   ├── A5200.pak/
    │   └── ...

🧠 Tipps
- BIOS-Dateinamen müssen exakt so heißen wie hier angegeben – MinUI ist darauf angewiesen.
- Verwende .zip-ROMs für Arcade-Systeme; .bin/.cue für CD-Systeme.
- Du kannst retroarch-[system].cfg anpassen, um Skalierung oder Shader zu ändern.

🖤 Credits
Erstellt von Timo & Sophie — The Analog Dreamers
„Keep Pixels Alive — Forever.“
Gewidmet allen Retro-Fans, die den Geist der 8-Bit-Ära bewahren.
