Analog Dreamers – Core Collection v1.1 — Édition Définitive
(RG35XX Plus / RGCubeXX MinUI Build)

🌈 Aperçu
Bienvenue dans l’Analog Dreamers Core Collection v1.1 — une expérience rétro entièrement testée et prête à jouer, conçue pour les utilisateurs de RG35XX Plus et RGCubeXX.
Chaque système est configuré pour une compatibilité et une simplicité maximales, selon le standard « Édition Robuste » utilisé dans toute cette collection.

🎮 Systèmes Robustes Inclus
# | Système | Core | Dossier BIOS | Remarques
1 | Atari 2600 | stella2014_libretro.so | — | Rapide, aucun BIOS requis
2 | Atari 5200 | atari800_libretro.so | /Bios/AT5200/ | Nécessite 5200.rom
3 | Atari Lynx | handy_libretro.so | /Bios/ATLYNX/ | Nécessite lynxboot.img
4 | Atari 7800 | prosystem_libretro.so | /Bios/AT7800/ | 7800 BIOS (U).rom ou (E).rom
5 | Sega CD | genesis_plus_gx_libretro.so | /Bios/SEGACD/ | BIOS régionaux requis
6 | PC Engine / TurboGrafx-16 | beetle_pce_fast_libretro.so | /Bios/PCECD/ | syscard1.pce, syscard2.pce, syscard3.pce
7 | Neo Geo | fbalpha2012_neogeo_libretro.so | /Bios/NEOGEO/ | Nécessite neogeo.zip
8 | C64 | vice_x64_libretro.so | /Bios/C64/ | Ensemble BIOS C64 original
9 | Amiga | puae_libretro.so | /Bios/AMIGA/ | kick13.rom, kick20.rom, kick31.rom
10 | Amiga CD | puae_libretro.so | /Bios/AMIGACD/ | Ensemble BIOS CD32 requis
11 | Atari ST | hatari_libretro.so | /Bios/ATARIST/ | Nécessite tos.img
12 | CPS / CPS2 / CPS3 | fbalpha2012_cps_libretro.so | — | Aucun BIOS requis
13 | SG-1000 | genesis_plus_gx_libretro.so | /Bios/SG1000/ | BIOS optionnel
14 | Sega 32X | picodrive_libretro.so | /Bios/SEGA32X/ | BIOS régionaux requis
15 | Naomi / Atomiswave | flycast_libretro.so | /Bios/NAOMI/ | Ensemble ROM correct requis
16 | Game & Watch | gw_libretro.so | — | Système minimal, aucun BIOS

⚙️ Guide d’installation
1️⃣ Copiez tous les dossiers de ce fichier ZIP à la racine de votre carte SD.
2️⃣ Placez les fichiers BIOS dans leurs dossiers correspondants (noms exacts requis).
3️⃣ Les ROMs vont dans les dossiers /Roms/[NomDuSystème]/ correspondants.
4️⃣ Démarrez votre appareil et sélectionnez le fichier .pak du système souhaité.
5️⃣ Jouez immédiatement — aucune configuration nécessaire !

🖥️ Paramètres d’affichage
Tous les systèmes sont configurés comme suit :
- Format d’image : Défini par le Core
- Mise à l’échelle entière : DÉSACTIVÉE
- Étirement : PLEIN ÉCRAN (pour les cores compatibles)
Vous pouvez modifier ces paramètres plus tard dans RetroArch selon vos préférences.

💾 Exemple de Structure de Dossier
/mnt/sdcard/
├── Bios/
│   ├── AT5200/5200.rom
│   ├── ATLYNX/lynxboot.img
│   ├── PCECD/syscard3.pce
│   └── ...
├── Roms/
│   ├── Atari 2600/
│   ├── Sega CD/
│   ├── Amiga CD/
│   └── ...
└── Emus/
    ├── rg35xxplus/
    │   ├── A2600.pak/
    │   ├── A5200.pak/
    │   └── ...

🧠 Conseils
- Les noms de fichiers BIOS doivent correspondre exactement — MinUI en dépend.
- Utilisez des ROMs .zip pour les systèmes d’arcade ; .bin/.cue pour les systèmes CD.
- Vous pouvez modifier retroarch-[system].cfg pour ajuster la mise à l’échelle ou les shaders.

🖤 Crédits
Créé par Timo & Sophie — The Analog Dreamers
« Keep Pixels Alive — Forever. »
Dédié à tous les fans de rétro qui préservent l’âme du 8-bit.
