Analog Dreamers – Core Collection v1.1 — Edición Definitiva
(RG35XX Plus / RGCubeXX MinUI Build)

🌈 Descripción general
Bienvenido a la Analog Dreamers Core Collection v1.1 — una experiencia retro completamente probada y lista para jugar, diseñada para usuarios de RG35XX Plus y RGCubeXX.
Cada sistema está configurado para ofrecer la máxima compatibilidad y facilidad de uso, siguiendo el estándar “Edición Robusta” utilizado en toda la colección.

🎮 Sistemas Robustos Incluidos
# | Sistema | Núcleo | Carpeta BIOS | Notas
1 | Atari 2600 | stella2014_libretro.so | — | Rápido, no requiere BIOS
2 | Atari 5200 | atari800_libretro.so | /Bios/AT5200/ | Requiere 5200.rom
3 | Atari Lynx | handy_libretro.so | /Bios/ATLYNX/ | Requiere lynxboot.img
4 | Atari 7800 | prosystem_libretro.so | /Bios/AT7800/ | 7800 BIOS (U).rom o (E).rom
5 | Sega CD | genesis_plus_gx_libretro.so | /Bios/SEGACD/ | Se requieren BIOS regionales
6 | PC Engine / TurboGrafx-16 | beetle_pce_fast_libretro.so | /Bios/PCECD/ | syscard1.pce, syscard2.pce, syscard3.pce
7 | Neo Geo | fbalpha2012_neogeo_libretro.so | /Bios/NEOGEO/ | Requiere neogeo.zip
8 | C64 | vice_x64_libretro.so | /Bios/C64/ | Conjunto BIOS C64 original
9 | Amiga | puae_libretro.so | /Bios/AMIGA/ | kick13.rom, kick20.rom, kick31.rom
10 | Amiga CD | puae_libretro.so | /Bios/AMIGACD/ | Se requiere BIOS CD32
11 | Atari ST | hatari_libretro.so | /Bios/ATARIST/ | Requiere tos.img
12 | CPS / CPS2 / CPS3 | fbalpha2012_cps_libretro.so | — | No requiere BIOS
13 | SG-1000 | genesis_plus_gx_libretro.so | /Bios/SG1000/ | BIOS opcional
14 | Sega 32X | picodrive_libretro.so | /Bios/SEGA32X/ | Se requieren BIOS regionales
15 | Naomi / Atomiswave | flycast_libretro.so | /Bios/NAOMI/ | Se requiere conjunto ROM correcto
16 | Game & Watch | gw_libretro.so | — | Sistema mínimo, no requiere BIOS

⚙️ Guía de instalación
1️⃣ Copia todas las carpetas de este archivo ZIP en la raíz de tu tarjeta SD.
2️⃣ Coloca los archivos BIOS en sus carpetas correspondientes (los nombres deben coincidir exactamente).
3️⃣ Las ROMs van en las carpetas /Roms/[NombreDelSistema]/ correspondientes.
4️⃣ Inicia tu dispositivo y selecciona el archivo .pak del sistema deseado.
5️⃣ ¡Juega al instante — sin configuración necesaria!

🖥️ Configuración de pantalla
Todos los sistemas están configurados de la siguiente manera:
- Relación de aspecto: Definido por el núcleo
- Escala entera: DESACTIVADA
- Estiramiento: PANTALLA COMPLETA (solo para núcleos compatibles)
Puedes modificar estos ajustes más tarde en RetroArch según tus preferencias.

💾 Ejemplo de estructura de carpetas
/mnt/sdcard/
├── Bios/
│   ├── AT5200/5200.rom
│   ├── ATLYNX/lynxboot.img
│   ├── PCECD/syscard3.pce
│   └── ...
├── Roms/
│   ├── Atari 2600/
│   ├── Sega CD/
│   ├── Amiga CD/
│   └── ...
└── Emus/
    ├── rg35xxplus/
    │   ├── A2600.pak/
    │   ├── A5200.pak/
    │   └── ...

🧠 Consejos
- Los nombres de los archivos BIOS deben coincidir exactamente — MinUI depende de ello.
- Usa ROMs .zip para sistemas arcade; .bin/.cue para sistemas de CD.
- Puedes editar retroarch-[system].cfg para cambiar la escala o los shaders.

🖤 Créditos
Creado por Timo & Sophie — The Analog Dreamers
“Keep Pixels Alive — Forever.”
Dedicado a todos los fans del retro que mantienen viva el alma del 8-bit.
