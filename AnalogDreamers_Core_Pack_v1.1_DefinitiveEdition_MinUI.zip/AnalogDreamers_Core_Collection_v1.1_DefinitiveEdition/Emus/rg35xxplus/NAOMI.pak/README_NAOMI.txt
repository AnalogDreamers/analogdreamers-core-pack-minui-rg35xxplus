Sega Naomi (NAOMI) — Analog Dreamers Core Collection v1.1
Core: /mnt/vendor/deep/retro/cores/flycast_libretro.so
BIOS: /mnt/sdcard/Bios/NAOMI/
ROMs: /mnt/sdcard/Roms/Naomi (NAOMI)/
Recommended formats: .zip, .chd, .lst
