#!/bin/sh
# Analog Dreamers — Sega CD / Mega-CD (SEGACD) (Core Collection v1.1)
echo "== SEGACD.pak start (rg35xxplus / sdcard) =="
RA_BIN=/mnt/vendor/deep/retro/retroarch
CORE_SO=/mnt/vendor/deep/retro/cores/picodrive_libretro.so
ROM_PATH="${1:-}"
APPEND_CFG=/mnt/sdcard/Emus/rg35xxplus/SEGACD.pak/retroarch-segacd.cfg
exec "$RA_BIN" -v -L "$CORE_SO" "$ROM_PATH" --appendconfig "$APPEND_CFG"
