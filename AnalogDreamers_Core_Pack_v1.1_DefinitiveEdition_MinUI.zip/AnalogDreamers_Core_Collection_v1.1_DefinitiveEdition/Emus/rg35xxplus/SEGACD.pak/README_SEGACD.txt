Sega CD / Mega-CD (SEGACD) — Analog Dreamers Core Collection v1.1
Core: /mnt/vendor/deep/retro/cores/picodrive_libretro.so
BIOS: /mnt/sdcard/Bios/SEGACD/
ROMs: /mnt/sdcard/Roms/Sega CD (SEGACD)/
Recommended formats: .chd, .cue, .bin
