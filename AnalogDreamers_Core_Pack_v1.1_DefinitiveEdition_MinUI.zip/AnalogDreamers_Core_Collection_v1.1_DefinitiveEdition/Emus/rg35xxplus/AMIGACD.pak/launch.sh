#!/bin/sh
# Analog Dreamers — Amiga CD32 (AMIGACD) (Core Collection v1.1)
echo "== AMIGACD.pak start (rg35xxplus / sdcard) =="
RA_BIN=/mnt/vendor/deep/retro/retroarch
CORE_SO=/mnt/vendor/deep/retro/cores/puae_libretro.so
ROM_PATH="${1:-}"
APPEND_CFG=/mnt/sdcard/Emus/rg35xxplus/AMIGACD.pak/retroarch-amigacd.cfg
exec "$RA_BIN" -v -L "$CORE_SO" "$ROM_PATH" --appendconfig "$APPEND_CFG"
