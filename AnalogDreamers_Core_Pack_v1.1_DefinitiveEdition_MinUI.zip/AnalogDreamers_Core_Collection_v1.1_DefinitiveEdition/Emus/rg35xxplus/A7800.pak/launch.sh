#!/bin/sh
# Analog Dreamers — Atari 7800 (A7800) (Core Collection v1.1)
echo "== A7800.pak start (rg35xxplus / sdcard) =="
RA_BIN=/mnt/vendor/deep/retro/retroarch
CORE_SO=/mnt/vendor/deep/retro/cores/prosystem_libretro.so
ROM_PATH="${1:-}"
APPEND_CFG=/mnt/sdcard/Emus/rg35xxplus/A7800.pak/retroarch-a7800.cfg
exec "$RA_BIN" -v -L "$CORE_SO" "$ROM_PATH" --appendconfig "$APPEND_CFG"
