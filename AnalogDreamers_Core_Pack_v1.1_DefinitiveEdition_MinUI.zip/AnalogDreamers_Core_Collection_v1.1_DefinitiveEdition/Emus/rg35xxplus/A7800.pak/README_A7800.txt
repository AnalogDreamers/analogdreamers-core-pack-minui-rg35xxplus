Atari 7800 (A7800) — Analog Dreamers Core Collection v1.1
Core: /mnt/vendor/deep/retro/cores/prosystem_libretro.so
BIOS: /mnt/sdcard/Bios/AT7800/
ROMs: /mnt/sdcard/Roms/Atari 7800 (A7800)/
Recommended formats: .a78, .zip
