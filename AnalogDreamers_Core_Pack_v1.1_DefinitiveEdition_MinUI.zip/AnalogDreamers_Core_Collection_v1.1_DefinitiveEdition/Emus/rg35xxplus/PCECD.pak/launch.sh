#!/bin/sh
# Analog Dreamers — PC Engine CD (PCECD) (Core Collection v1.1)
echo "== PCECD.pak start (rg35xxplus / sdcard) =="
RA_BIN=/mnt/vendor/deep/retro/retroarch
CORE_SO=/mnt/vendor/deep/retro/cores/mednafen_pce_fast_libretro.so
ROM_PATH="${1:-}"
APPEND_CFG=/mnt/sdcard/Emus/rg35xxplus/PCECD.pak/retroarch-pcecd.cfg
exec "$RA_BIN" -v -L "$CORE_SO" "$ROM_PATH" --appendconfig "$APPEND_CFG"
