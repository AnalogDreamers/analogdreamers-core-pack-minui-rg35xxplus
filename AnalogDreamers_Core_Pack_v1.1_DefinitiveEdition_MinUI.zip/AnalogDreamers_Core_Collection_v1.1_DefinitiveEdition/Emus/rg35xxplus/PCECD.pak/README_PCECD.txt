PC Engine CD (PCECD) — Analog Dreamers Core Collection v1.1
Core: /mnt/vendor/deep/retro/cores/mednafen_pce_fast_libretro.so
BIOS: /mnt/sdcard/Bios/PCECD/
ROMs: /mnt/sdcard/Roms/PC Engine CD (PCECD)/
Recommended formats: .chd, .cue, .bin, .zip
