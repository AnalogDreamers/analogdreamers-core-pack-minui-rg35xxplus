Neo Geo (NEO) — Analog Dreamers Core Collection v1.1
Core: /mnt/vendor/deep/retro/cores/fbneo_libretro.so
BIOS: /mnt/sdcard/Bios/NEO/
ROMs: /mnt/sdcard/Roms/Neo Geo (NEO)/
Recommended formats: .zip
