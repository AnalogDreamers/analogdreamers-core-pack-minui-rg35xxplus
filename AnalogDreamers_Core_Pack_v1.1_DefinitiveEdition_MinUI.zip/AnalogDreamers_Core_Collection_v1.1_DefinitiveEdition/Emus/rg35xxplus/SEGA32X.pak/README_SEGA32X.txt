Sega 32X (SEGA32X) — Analog Dreamers Core Collection v1.1
Core: /mnt/vendor/deep/retro/cores/picodrive_libretro.so
BIOS: /mnt/sdcard/Bios/SEGA32X/
ROMs: /mnt/sdcard/Roms/Sega 32X (SEGA32X)/
Recommended formats: .32x, .bin, .zip
