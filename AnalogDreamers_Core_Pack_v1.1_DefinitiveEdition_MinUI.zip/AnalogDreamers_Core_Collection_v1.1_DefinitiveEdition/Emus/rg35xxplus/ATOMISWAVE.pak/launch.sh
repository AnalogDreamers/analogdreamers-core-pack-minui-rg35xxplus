#!/bin/sh
# Analog Dreamers — Atomiswave (AW) (Core Collection v1.1)
echo "== ATOMISWAVE.pak start (rg35xxplus / sdcard) =="
RA_BIN=/mnt/vendor/deep/retro/retroarch
CORE_SO=/mnt/vendor/deep/retro/cores/flycast_libretro.so
ROM_PATH="${1:-}"
APPEND_CFG=/mnt/sdcard/Emus/rg35xxplus/ATOMISWAVE.pak/retroarch-atomiswave.cfg
exec "$RA_BIN" -v -L "$CORE_SO" "$ROM_PATH" --appendconfig "$APPEND_CFG"
