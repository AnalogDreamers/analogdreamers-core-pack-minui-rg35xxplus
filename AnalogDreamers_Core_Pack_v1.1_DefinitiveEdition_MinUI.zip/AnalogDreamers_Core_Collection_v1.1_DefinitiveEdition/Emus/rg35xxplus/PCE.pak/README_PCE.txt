PC Engine / TurboGrafx-16 (PCE) — Analog Dreamers Core Collection v1.1
Core: /mnt/vendor/deep/retro/cores/mednafen_pce_fast_libretro.so
BIOS: /mnt/sdcard/Bios/PCE/
ROMs: /mnt/sdcard/Roms/PC Engine (PCE)/
Recommended formats: .pce, .zip
