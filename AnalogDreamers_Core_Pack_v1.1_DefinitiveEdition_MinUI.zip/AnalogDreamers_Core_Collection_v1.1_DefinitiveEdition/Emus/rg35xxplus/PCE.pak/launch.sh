#!/bin/sh
# Analog Dreamers — PC Engine / TurboGrafx-16 (PCE) (Core Collection v1.1)
echo "== PCE.pak start (rg35xxplus / sdcard) =="
RA_BIN=/mnt/vendor/deep/retro/retroarch
CORE_SO=/mnt/vendor/deep/retro/cores/mednafen_pce_fast_libretro.so
ROM_PATH="${1:-}"
APPEND_CFG=/mnt/sdcard/Emus/rg35xxplus/PCE.pak/retroarch-pce.cfg
exec "$RA_BIN" -v -L "$CORE_SO" "$ROM_PATH" --appendconfig "$APPEND_CFG"
