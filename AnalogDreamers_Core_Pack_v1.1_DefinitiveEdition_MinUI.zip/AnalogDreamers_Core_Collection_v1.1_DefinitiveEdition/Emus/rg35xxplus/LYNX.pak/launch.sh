#!/bin/sh
# Analog Dreamers — Atari Lynx (LYNX) (Core Collection v1.1)
echo "== LYNX.pak start (rg35xxplus / sdcard) =="
RA_BIN=/mnt/vendor/deep/retro/retroarch
CORE_SO=/mnt/vendor/deep/retro/cores/handy_libretro.so
ROM_PATH="${1:-}"
APPEND_CFG=/mnt/sdcard/Emus/rg35xxplus/LYNX.pak/retroarch-lynx.cfg
exec "$RA_BIN" -v -L "$CORE_SO" "$ROM_PATH" --appendconfig "$APPEND_CFG"
