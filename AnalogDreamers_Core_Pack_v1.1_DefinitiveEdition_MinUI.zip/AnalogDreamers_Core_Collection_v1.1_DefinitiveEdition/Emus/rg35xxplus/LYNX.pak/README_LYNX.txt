Atari Lynx (LYNX) — Analog Dreamers Core Collection v1.1
Core: /mnt/vendor/deep/retro/cores/handy_libretro.so
BIOS: /mnt/sdcard/Bios/ATLYNX/
ROMs: /mnt/sdcard/Roms/Atari Lynx (LYNX)/
Recommended formats: .lnx, .zip
