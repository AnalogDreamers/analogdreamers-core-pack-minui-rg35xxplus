Atari 2600 (A2600) — Analog Dreamers Core Collection v1.1
Core: /mnt/vendor/deep/retro/cores/stella2014_libretro.so
BIOS: /mnt/sdcard/Bios/AT2600/
ROMs: /mnt/sdcard/Roms/Atari 2600 (A2600)/
Recommended formats: .bin, .a26, .zip
