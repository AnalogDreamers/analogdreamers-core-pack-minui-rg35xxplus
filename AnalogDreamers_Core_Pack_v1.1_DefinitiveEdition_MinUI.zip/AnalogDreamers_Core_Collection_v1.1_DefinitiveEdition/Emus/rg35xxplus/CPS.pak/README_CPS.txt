Capcom Play System (CPS) — Analog Dreamers Core Collection v1.1
Core: /mnt/vendor/deep/retro/cores/fbneo_libretro.so
BIOS: /mnt/sdcard/Bios/CPS/
ROMs: /mnt/sdcard/Roms/CPS (Arcade)/
Recommended formats: .zip
