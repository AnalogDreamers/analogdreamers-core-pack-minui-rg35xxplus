Atari 5200 (A5200) — Analog Dreamers Core Collection v1.1
Core: /mnt/vendor/deep/retro/cores/atari800_libretro.so
BIOS: /mnt/sdcard/Bios/AT5200/
ROMs: /mnt/sdcard/Roms/Atari 5200 (A5200)/
Recommended formats: .a52, .bin
