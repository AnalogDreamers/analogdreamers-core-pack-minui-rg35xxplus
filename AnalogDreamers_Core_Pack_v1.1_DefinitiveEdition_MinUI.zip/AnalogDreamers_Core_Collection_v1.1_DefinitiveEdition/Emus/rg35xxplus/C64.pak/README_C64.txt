Commodore 64 (C64) — Analog Dreamers Core Collection v1.1
Core: /mnt/vendor/deep/retro/cores/vice_x64_libretro.so
BIOS: /mnt/sdcard/Bios/C64/
ROMs: /mnt/sdcard/Roms/Commodore 64 (C64)/
Recommended formats: .d64, .t64, .prg, .crt, .zip
