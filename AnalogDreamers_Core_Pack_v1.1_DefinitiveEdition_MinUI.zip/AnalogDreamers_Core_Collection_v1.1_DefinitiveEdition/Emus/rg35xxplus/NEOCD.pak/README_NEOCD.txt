Neo Geo CD (NEOCD) — Analog Dreamers Core Collection v1.1
Core: /mnt/vendor/deep/retro/cores/neocd_libretro.so
BIOS: /mnt/sdcard/Bios/NEOCD/
ROMs: /mnt/sdcard/Roms/Neo Geo CD (NEOCD)/
Recommended formats: .chd, .cue, .bin
