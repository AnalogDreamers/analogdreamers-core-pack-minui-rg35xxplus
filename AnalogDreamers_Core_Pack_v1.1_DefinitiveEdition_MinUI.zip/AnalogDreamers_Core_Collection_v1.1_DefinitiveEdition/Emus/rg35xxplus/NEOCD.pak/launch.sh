#!/bin/sh
# Analog Dreamers — Neo Geo CD (NEOCD) (Core Collection v1.1)
echo "== NEOCD.pak start (rg35xxplus / sdcard) =="
RA_BIN=/mnt/vendor/deep/retro/retroarch
CORE_SO=/mnt/vendor/deep/retro/cores/neocd_libretro.so
ROM_PATH="${1:-}"
APPEND_CFG=/mnt/sdcard/Emus/rg35xxplus/NEOCD.pak/retroarch-neocd.cfg
exec "$RA_BIN" -v -L "$CORE_SO" "$ROM_PATH" --appendconfig "$APPEND_CFG"
