Commodore Amiga (AMIGA) — Analog Dreamers Core Collection v1.1
Core: /mnt/vendor/deep/retro/cores/puae_libretro.so
BIOS: /mnt/sdcard/Bios/AMIGA/
ROMs: /mnt/sdcard/Roms/Amiga (AMIGA)/
Recommended formats: .adf, .adz, .hdf, .lha, .zip
