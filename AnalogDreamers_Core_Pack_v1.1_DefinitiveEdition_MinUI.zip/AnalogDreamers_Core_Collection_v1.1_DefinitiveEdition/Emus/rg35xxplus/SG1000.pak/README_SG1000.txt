Sega SG-1000 (SG1000) — Analog Dreamers Core Collection v1.1
Core: /mnt/vendor/deep/retro/cores/genesis_plus_gx_libretro.so
BIOS: /mnt/sdcard/Bios/SG1000/
ROMs: /mnt/sdcard/Roms/SG-1000 (SG1000)/
Recommended formats: .sg, .zip
