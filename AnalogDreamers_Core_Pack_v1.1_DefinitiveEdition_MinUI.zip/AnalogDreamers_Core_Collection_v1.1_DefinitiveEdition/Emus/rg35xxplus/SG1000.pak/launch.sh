#!/bin/sh
# Analog Dreamers — Sega SG-1000 (SG1000) (Core Collection v1.1)
echo "== SG1000.pak start (rg35xxplus / sdcard) =="
RA_BIN=/mnt/vendor/deep/retro/retroarch
CORE_SO=/mnt/vendor/deep/retro/cores/genesis_plus_gx_libretro.so
ROM_PATH="${1:-}"
APPEND_CFG=/mnt/sdcard/Emus/rg35xxplus/SG1000.pak/retroarch-sg1000.cfg
exec "$RA_BIN" -v -L "$CORE_SO" "$ROM_PATH" --appendconfig "$APPEND_CFG"
